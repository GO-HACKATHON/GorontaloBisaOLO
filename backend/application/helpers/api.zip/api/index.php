<?php 

date_default_timezone_set("Asia/Makassar");

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

 
require_once "src/firebaseLib.php";
   
const DEFAULT_URL = 'https://ebentor-a82be.firebaseio.com';
const DEFAULT_TOKEN = 'RClkLV3veuMqkz6TkcdztcxbT31Fo5MUls6me6jF';
const DEFAULT_PATH = '';

$firebase = new \Firebase\FirebaseLib(DEFAULT_URL, DEFAULT_TOKEN);


$q = $firebase->get(DEFAULT_PATH.'passenger');
$q = json_decode($q);

print_r($q);



	